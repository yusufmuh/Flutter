import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:marketplace_app/models/product.dart';

class EditProductScreen extends StatefulWidget {
  final Product product;
  EditProductScreen({this.product});

  @override
  _EditProductScreenState createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<EditProductScreen> {
  final _formKey = GlobalKey<FormState>();
  String name, description, category;
  int price;

  void _editProduct() async {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      var updatedProduct = Product(
        id: widget.product.id,
        name: name,
        description: description,
        price: price,
        category: category,
      );
      await FirebaseFirestore.instance
          .collection('products')
          .doc(widget.product.id)
          .update(updatedProduct.toMap());
      Navigator.pop(context);
    }
  }

  @override
  void initState() {
    super.initState();
    name = widget.product.name;
    description = widget.product.description;
    category = widget.product.category;
    price = widget.product.price;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Edit Product')),
      body: Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            TextFormField(
              initialValue: name,
              decoration: InputDecoration(labelText: 'Product Name'),
              onSaved: (value) => name = value,
              validator: (value) => value.isEmpty ? 'Enter Product Name' : null,
            ),
            TextFormField(
              initialValue: description,
              decoration: InputDecoration(labelText: 'Description'),
              onSaved: (value) => description = value,
              validator: (value) => value.isEmpty ? 'Enter Description' : null,
            ),
            TextFormField(
              initialValue: price.toString(),
              decoration: InputDecoration(labelText: 'Price'),
              keyboardType: TextInputType.number,
              onSaved: (value) => price = int.parse(value),
              validator: (value) => value.isEmpty ? 'Enter Price' : null,
            ),
            TextFormField(
              initialValue: category,
              decoration: InputDecoration(labelText: 'Category'),
              onSaved: (value) => category = value,
              validator: (value) => value.isEmpty ? 'Enter Category' : null,
            ),
            ElevatedButton(
              onPressed: _editProduct,
              child: Text('Save Changes'),
            ),
          ],
        ),
      ),
    );
  }
}
