class Product {
  String id;
  String name;
  String description;
  int price;
  String category;

  Product({this.id, this.name, this.description, this.price, this.category});

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'description': description,
      'price': price,
      'category': category,
    };
  }

  static Product fromMap(Map<String, dynamic> map, String id) {
    return Product(
      id: id,
      name: map['name'],
      description: map['description'],
      price: map['price'],
      category: map['category'],
    );
  }
}
