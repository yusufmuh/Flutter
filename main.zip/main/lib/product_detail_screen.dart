import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:marketplace_app/models/product.dart';
import 'package:marketplace_app/screens/edit_product_screen.dart';

class ProductDetailScreen extends StatelessWidget {
  final Product product;
  ProductDetailScreen({this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(product.name),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EditProductScreen(product: product),
                ),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () async {
              await FirebaseFirestore.instance
                  .collection('products')
                  .doc(product.id)
                  .delete();
              Navigator.pop(context);
            },
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(product.name, style: TextStyle(fontSize: 24)),
            SizedBox(height: 10),
            Text('Description: ${product.description}'),
            SizedBox(height: 10),
            Text('Price: ${product.price}'),
            SizedBox(height: 10),
            Text('Category: ${product.category}'),
          ],
        ),
      ),
    );
  }
}
