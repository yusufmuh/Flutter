import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:marketplace_app/models/product.dart';

class AddProductScreen extends StatefulWidget {
  @override
  _AddProductScreenState createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();
  String name, description, category;
  int price;

  void _addProduct() async {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      var product = Product(
        name: name,
        description: description,
        price: price,
        category: category,
      );
      await FirebaseFirestore.instance.collection('products').add(product.toMap());
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Product')),
      body: Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            TextFormField(
              decoration: InputDecoration(labelText: 'Product Name'),
              onSaved: (value) => name = value,
              validator: (value) => value.isEmpty ? 'Enter Product Name' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Description'),
              onSaved: (value) => description = value,
              validator: (value) => value.isEmpty ? 'Enter Description' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Price'),
              keyboardType: TextInputType.number,
              onSaved: (value) => price = int.parse(value),
              validator: (value) => value.isEmpty ? 'Enter Price' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Category'),
              onSaved: (value) => category = value,
              validator: (value) => value.isEmpty ? 'Enter Category' : null,
            ),
            ElevatedButton(
              onPressed: _addProduct,
              child: Text('Add Product'),
            ),
          ],
        ),
      ),
    );
  }
}
