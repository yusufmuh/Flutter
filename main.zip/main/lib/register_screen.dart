import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class RegisterScreen extends StatefulWidget {
  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  String email, password, fullName, phoneNumber;

  void _register() async {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      try {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
            email: email, password: password);
        Navigator.pushReplacementNamed(context, '/home');
      } catch (e) {
        print(e); // Handle error
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Register')),
      body: Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            TextFormField(
              decoration: InputDecoration(labelText: 'Full Name'),
              onSaved: (value) => fullName = value,
              validator: (value) => value.isEmpty ? 'Enter Full Name' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Phone Number'),
              onSaved: (value) => phoneNumber = value,
              validator: (value) => value.isEmpty ? 'Enter Phone Number' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Email'),
              onSaved: (value) => email = value,
              validator: (value) => value.isEmpty ? 'Enter Email' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
              onSaved: (value) => password = value,
              validator: (value) => value.isEmpty ? 'Enter Password' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Confirm Password'),
              obscureText: true,
              validator: (value) =>
                  value != password ? 'Passwords do not match' : null,
            ),
            ElevatedButton(
              onPressed: _register,
              child: Text('Register'),
            ),
            TextButton(
              onPressed: () => Navigator.pushNamed(context, '/login'),
              child: Text('Already have an account? Login here'),
            ),
          ],
        ),
      ),
    );
  }
}
